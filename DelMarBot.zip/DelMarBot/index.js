require('dotenv').config();

process.on('unhandledRejection', err => {
  console.error('Unhandled Rejection:', err);
});

process.on('uncaughtException', err => {
  console.error('Uncaught Exception:', err);
});

const client = require('./src/bot/client');
const loadCommands = require('./src/bot/commandLoader');
const loadEvents = require('./src/bot/eventLoader');
const sequelize = require('./src/database/connection');
const dashboard = require('./src/dashboard/app');

loadCommands(client);
loadEvents(client);

module.exports = {
  name: 'clientReady',
  once: true,
  execute(client) {
    console.log(`🤖 Bot connecté : ${client.user.tag}`);
  }
};

client.on('interactionCreate', async interaction => {
  if (!interaction.isChatInputCommand()) return;

  const command = client.commands.get(interaction.commandName);
  if (!command) return;

  try {
    await command.execute(interaction);
  } catch (error) {
    console.error(error);
    if (!interaction.replied) {
      await interaction.reply({
        content: "❌ Une erreur est survenue.",
        ephemeral: true
      });
    }
  }
});

sequelize.sync().then(() => {

  client.login(process.env.DISCORD_TOKEN);

  const PORT = process.env.PORT || 3000;

  dashboard.listen(PORT, () => {
    console.log(`🌐 Dashboard lancé sur port ${PORT}`);
  });

});