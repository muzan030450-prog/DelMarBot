const { 
  Client, 
  GatewayIntentBits, 
  Partials, 
  Collection 
} = require('discord.js');

const client = new Client({

  intents: [

    // 🔹 Base
    GatewayIntentBits.Guilds,

    // 🔹 Messages
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,

    // 🔹 Membres (welcome, logs, modération)
    GatewayIntentBits.GuildMembers,

    // 🔹 Réactions (logs + rôles réaction)
    GatewayIntentBits.GuildMessageReactions,

    // 🔹 Vocal (XP vocal)
    GatewayIntentBits.GuildVoiceStates,

    // 🔹 Logs audit (ban/kick/role updates)
    GatewayIntentBits.GuildModeration,

    // 🔹 Emojis & stickers
    GatewayIntentBits.GuildEmojisAndStickers,

    // 🔹 Webhooks (logs)
    GatewayIntentBits.GuildWebhooks,

    // 🔹 Threads
    GatewayIntentBits.GuildMessageTyping,
    GatewayIntentBits.GuildScheduledEvents
  ],

  partials: [
    Partials.Message,
    Partials.Channel,
    Partials.Reaction,
    Partials.GuildMember,
    Partials.User
  ]
});

client.commands = new Collection();

module.exports = client;