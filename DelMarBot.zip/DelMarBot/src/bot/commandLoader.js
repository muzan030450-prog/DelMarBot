const fs = require('fs');
const path = require('path');

function loadCommands(client) {

  // 🔄 Reset propre des commandes
  client.commands.clear();

  const commandsPath = path.join(__dirname, 'commands');
  const commandFolders = fs.readdirSync(commandsPath);

  for (const folder of commandFolders) {

    const folderPath = path.join(commandsPath, folder);

    // Sécurité si ce n’est pas un dossier
    if (!fs.lstatSync(folderPath).isDirectory()) continue;

    const commandFiles = fs
      .readdirSync(folderPath)
      .filter(file => file.endsWith('.js'));

    for (const file of commandFiles) {

      const filePath = path.join(folderPath, file);

      try {

        // 🔁 Clear cache pour éviter bug reload
        delete require.cache[require.resolve(filePath)];

        const command = require(filePath);

        // 🔒 Sécurité anti crash
        if (!command || !command.data || !command.data.name) {
          console.log(`❌ Commande invalide ignorée: ${file}`);
          continue;
        }

        // ⚠️ Protection doublon
        if (client.commands.has(command.data.name)) {
          console.log(`⚠️ Doublon détecté: ${command.data.name}`);
          continue;
        }

        client.commands.set(command.data.name, command);
        console.log(`✅ Commande chargée: ${command.data.name}`);

      } catch (error) {
        console.error(`❌ Erreur chargement ${file}:`, error.message);
      }
    }
  }

  console.log(`🔥 Total commandes chargées: ${client.commands.size}`);
}

module.exports = loadCommands;