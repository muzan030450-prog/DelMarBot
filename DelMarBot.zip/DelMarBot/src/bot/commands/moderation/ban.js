const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const checkPermission = require('../../../middlewares/checkPermission');
const SecurityService = require('../../services/SecurityService');
const LogService = require('../../services/LogService');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Bannir un membre du serveur')
    .addUserOption(option =>
      option
        .setName('user')
        .setDescription('Utilisateur à bannir')
        .setRequired(true))
    .addStringOption(option =>
      option
        .setName('reason')
        .setDescription('Raison du bannissement')
        .setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

  async execute(interaction) {

    // 🔐 Vérification whitelist niveau Mod minimum (50)
    if (!(await checkPermission(50)(interaction))) return;

    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason');

    const guild = interaction.guild;
    const member = await guild.members.fetch(target.id).catch(() => null);

    // 🚫 Vérifie que le membre existe
    if (!member) {
      return interaction.reply({
        content: "❌ Utilisateur introuvable sur ce serveur.",
        ephemeral: true
      });
    }

    // 🛡 Protection hiérarchie
    const securityCheck = await SecurityService.canModerate(interaction, target);

    if (!securityCheck.allowed) {
      return interaction.reply({
        content: securityCheck.reason,
        ephemeral: true
      });
    }

    // 🚫 Empêche le self-ban
    if (target.id === interaction.user.id) {
      return interaction.reply({
        content: "⛔ Vous ne pouvez pas vous bannir vous-même.",
        ephemeral: true
      });
    }

    // 🚫 Empêche de bannir le propriétaire du serveur
    if (guild.ownerId === target.id) {
      return interaction.reply({
        content: "⛔ Impossible de bannir le propriétaire du serveur.",
        ephemeral: true
      });
    }

    try {

      await member.ban({ reason });

      // 📋 Log
      await LogService.logModeration(
        guild,
        "BAN",
        target,
        interaction.user,
        reason
      );

      await interaction.reply({
        content: `🔨 ${target.tag} a été banni.\n📌 Raison : ${reason}`
      });

    } catch (error) {

      console.error("Erreur BAN :", error);

      await interaction.reply({
        content: "❌ Une erreur est survenue lors du bannissement.",
        ephemeral: true
      });

    }
  }
};