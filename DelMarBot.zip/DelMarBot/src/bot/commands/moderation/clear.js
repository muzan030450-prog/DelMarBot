const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const checkPermission = require('../../../middlewares/checkPermission');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('clear')
    .setDescription('Supprimer des messages')
    .addIntegerOption(opt =>
      opt.setName('amount').setDescription('Nombre de messages').setRequired(true)),

  async execute(interaction) {

    if (!(await checkPermission(50)(interaction))) return;

    const amount = interaction.options.getInteger('amount');

    if (amount < 1 || amount > 100) {
      return interaction.reply({ content: "Entre 1 et 100 messages.", ephemeral: true });
    }

    await interaction.channel.bulkDelete(amount, true);

    interaction.reply({ content: `🧹 ${amount} messages supprimés.`, ephemeral: true });
  }
};