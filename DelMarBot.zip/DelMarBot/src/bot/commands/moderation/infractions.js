const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const Warn = require('../../../database/models/Warn');
const checkWhitelist = require('../../../middlewares/checkWhitelist');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('infractions')
    .setDescription('Voir l’historique complet des infractions')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('Utilisateur')
        .setRequired(true)),

  async execute(interaction) {

    if (!(await checkWhitelist(interaction))) return;

    const target = interaction.options.getUser('user');

    const warns = await Warn.findAll({
      where: {
        guild_id: interaction.guild.id,
        user_id: target.id
      },
      order: [['createdAt', 'DESC']]
    });

    if (!warns.length) {
      return interaction.reply({
        content: `${target.tag} n’a aucune infraction.`,
        ephemeral: true
      });
    }

    const embed = new EmbedBuilder()
      .setColor("Red")
      .setTitle(`📊 Historique complet - ${target.tag}`)
      .setThumbnail(target.displayAvatarURL())
      .setTimestamp();

    warns.slice(0, 10).forEach((w, index) => {
      embed.addFields({
        name: `Infraction #${warns.length - index}`,
        value: `Raison: ${w.reason}\nModérateur: <@${w.moderator_id}>`
      });
    });

    embed.setFooter({
      text: `Total infractions: ${warns.length}`
    });

    interaction.reply({ embeds: [embed], ephemeral: true });
  }
};