const { SlashCommandBuilder } = require('discord.js');
const checkPermission = require('../../../middlewares/checkPermission');
const LogService = require('../../services/LogService');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Expulser un membre')
    .addUserOption(opt =>
      opt.setName('user').setDescription('Utilisateur').setRequired(true))
    .addStringOption(opt =>
      opt.setName('reason').setDescription('Raison').setRequired(false)),

  async execute(interaction) {

    if (!(await checkPermission(50)(interaction))) return;

    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || "Aucune raison";

    const member = await interaction.guild.members.fetch(target.id);

    if (!member.kickable) {
      return interaction.reply({
        content: "Impossible d'expulser cet utilisateur.",
        ephemeral: true
      });
    }

    await member.kick(reason);

    await LogService.logModeration(
      interaction.guild,
      "KICK",
      target,
      interaction.user,
      reason
    );

    interaction.reply(`👢 ${target.tag} a été expulsé.`);
  }
};