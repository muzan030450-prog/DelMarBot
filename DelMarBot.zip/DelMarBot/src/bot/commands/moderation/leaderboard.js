const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const Xp = require('../../../database/models/Xp');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('infractions-leaderboard')
    .setDescription('Top XP du serveur'),

  async execute(interaction) {

    const top = await Xp.findAll({
      where: { guild_id: interaction.guild.id },
      order: [['level', 'DESC'], ['xp', 'DESC']],
      limit: 10
    });

    if (!top.length) {
      return interaction.reply("Aucune donnée XP.");
    }

    const description = await Promise.all(
      top.map(async (user, index) => {
        const member = await interaction.guild.members.fetch(user.user_id).catch(() => null);
        if (!member) return null;
        return `**${index + 1}.** ${member.user.tag} → Niveau ${user.level}`;
      })
    );

    const embed = new EmbedBuilder()
      .setColor("Gold")
      .setTitle("🏆 Leaderboard XP")
      .setDescription(description.filter(Boolean).join("\n"))
      .setTimestamp();

    interaction.reply({ embeds: [embed] });
  }
};