const { SlashCommandBuilder } = require('discord.js');
const checkPermission = require('../../../middlewares/checkPermission');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('lock')
    .setDescription('Verrouiller le salon actuel'),

  async execute(interaction) {

    if (!(await checkPermission(50)(interaction))) return;

    await interaction.channel.permissionOverwrites.edit(
      interaction.guild.roles.everyone,
      { SendMessages: false }
    );

    await interaction.reply("🔒 Salon verrouillé.");
  }
};