const { SlashCommandBuilder } = require('discord.js');
const checkPermission = require('../../../middlewares/checkPermission');
const LogService = require('../../services/LogService');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('mute')
    .setDescription('Mute un membre')
    .addUserOption(opt =>
      opt.setName('user').setDescription('Utilisateur').setRequired(true))
    .addIntegerOption(opt =>
      opt.setName('minutes').setDescription('Durée en minutes').setRequired(true))
    .addStringOption(opt =>
      opt.setName('reason').setDescription('Raison').setRequired(false)),

  async execute(interaction) {

    if (!(await checkPermission(50)(interaction))) return;

    const target = interaction.options.getUser('user');
    const minutes = interaction.options.getInteger('minutes');
    const reason = interaction.options.getString('reason') || "Aucune raison";

    const member = await interaction.guild.members.fetch(target.id);

    if (!member.moderatable) {
      return interaction.reply({ content: "Impossible de modérer cet utilisateur.", ephemeral: true });
    }

    await member.timeout(minutes * 60 * 1000, reason);

    await LogService.logModeration(
      interaction.guild,
      "MUTE",
      target,
      interaction.user,
      reason
    );

    interaction.reply(`🔇 ${target.tag} mute ${minutes} minutes.`);
  }
};