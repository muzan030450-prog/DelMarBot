const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const Xp = require('../../../database/models/Xp');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('infractions-rank')
    .setDescription('Voir son niveau ou celui d’un membre')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('Utilisateur')
        .setRequired(false)),

  async execute(interaction) {

    const target = interaction.options.getUser('user') || interaction.user;

    const data = await Xp.findOne({
      where: {
        guild_id: interaction.guild.id,
        user_id: target.id
      }
    });

    if (!data) {
      return interaction.reply({
        content: "Aucune donnée XP.",
        ephemeral: true
      });
    }

    const embed = new EmbedBuilder()
      .setColor("Blue")
      .setTitle(`🎖 Niveau de ${target.tag}`)
      .setThumbnail(target.displayAvatarURL())
      .addFields(
        { name: "Niveau", value: `${data.level}`, inline: true },
        { name: "XP", value: `${data.xp}`, inline: true }
      )
      .setTimestamp();

    interaction.reply({ embeds: [embed] });
  }
};