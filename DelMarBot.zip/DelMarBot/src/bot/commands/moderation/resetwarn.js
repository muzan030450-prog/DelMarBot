const { SlashCommandBuilder } = require('discord.js');
const Warn = require('../../../database/models/Warn');
const checkWhitelist = require('../../../middlewares/checkWhitelist');
const SecurityService = require('../../services/SecurityService');
const LogService = require('../../services/LogService');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('resetwarn')
    .setDescription('Supprimer tous les avertissements d’un membre')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('Utilisateur')
        .setRequired(true)),

  async execute(interaction) {

    // 🔐 Vérification whitelist staff
    if (!(await checkWhitelist(interaction))) return;

    const target = interaction.options.getUser('user');

    // 🔎 Vérification que le membre existe dans le serveur
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);

    if (!member) {
      return interaction.reply({
        content: "Utilisateur introuvable sur ce serveur.",
        ephemeral: true
      });
    }

    // 🛡 Sécurité hiérarchie
    const securityCheck = await SecurityService.canModerate(interaction, target);

    if (!securityCheck.allowed) {
      return interaction.reply({
        content: securityCheck.reason,
        ephemeral: true
      });
    }

    // 📜 Suppression des warns
    const deleted = await Warn.destroy({
      where: {
        guild_id: interaction.guild.id,
        user_id: target.id
      }
    });

    if (deleted === 0) {
      return interaction.reply({
        content: `${target.tag} n’a aucun avertissement.`,
        ephemeral: true
      });
    }

    // 📋 Log staff
    await LogService.logModeration(
      interaction.guild,
      "RESET WARNS",
      target,
      interaction.user,
      `Suppression de ${deleted} avertissement(s)`
    );

    await interaction.reply({
      content: `🧹 ${deleted} avertissement(s) supprimé(s) pour ${target.tag}.`,
      ephemeral: true
    });
  }
};