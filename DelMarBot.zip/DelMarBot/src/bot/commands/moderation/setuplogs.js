const { SlashCommandBuilder } = require('discord.js');
const LogSetupService = require('../../services/LogSetupService');
const checkPermission = require('../../../middlewares/checkPermission');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setup-logs')
    .setDescription('Créer automatiquement les salons de logs'),

  async execute(interaction) {

    if (!(await checkPermission(100)(interaction))) return;

    const result = await LogSetupService.setupLogs(interaction.guild);

    if (!result) {
      return interaction.reply({
        content: "Les logs sont déjà configurés.",
        ephemeral: true
      });
    }

    interaction.reply("📜 Salons de logs créés avec succès.");
  }
};