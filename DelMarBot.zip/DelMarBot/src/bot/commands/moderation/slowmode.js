const { SlashCommandBuilder } = require('discord.js');
const checkWhitelist = require('../../../middlewares/checkWhitelist');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('slowmode')
    .setDescription('Définir le slowmode du salon')
    .addIntegerOption(option =>
      option.setName('seconds')
        .setDescription('Durée en secondes (0 pour désactiver)')
        .setRequired(true)),

  async execute(interaction) {

    if (!(await checkWhitelist(interaction))) return;

    const seconds = interaction.options.getInteger('seconds');

    if (seconds < 0 || seconds > 21600) {
      return interaction.reply({
        content: "Valeur invalide (0 à 21600 secondes).",
        ephemeral: true
      });
    }

    await interaction.channel.setRateLimitPerUser(seconds);

    interaction.reply({
      content: `⏳ Slowmode défini à ${seconds} seconde(s).`,
      ephemeral: true
    });
  }
};