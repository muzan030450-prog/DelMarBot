const { SlashCommandBuilder } = require('discord.js');
const checkPermission = require('../../../middlewares/checkPermission');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unlock')
    .setDescription('Déverrouiller le salon'),

  async execute(interaction) {

    if (!(await checkPermission(50)(interaction))) return;

    await interaction.channel.permissionOverwrites.edit(
      interaction.guild.roles.everyone,
      { SendMessages: null }
    );

    interaction.reply("🔓 Salon déverrouillé.");
  }
};