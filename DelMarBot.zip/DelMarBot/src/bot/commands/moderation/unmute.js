const { SlashCommandBuilder } = require('discord.js');
const checkPermission = require('../../../middlewares/checkPermission');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unmute')
    .setDescription('Retirer un mute')
    .addUserOption(opt =>
      opt.setName('user').setDescription('Utilisateur').setRequired(true)),

  async execute(interaction) {

    if (!(await checkPermission(50)(interaction))) return;

    const target = interaction.options.getUser('user');
    const member = await interaction.guild.members.fetch(target.id);

    await member.timeout(null);

    interaction.reply(`🔊 ${target.tag} a été unmute.`);
  }
};