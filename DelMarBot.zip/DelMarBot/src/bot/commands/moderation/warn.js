const { SlashCommandBuilder } = require('discord.js');
const checkPermission = require('../../middlewares/checkPermission');
const SecurityService = require('../../services/SecurityService');
const ModerationService = require('../../services/ModerationService');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Avertir un membre')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('Utilisateur')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('Raison')
        .setRequired(true)),

  async execute(interaction) {

    if (!(await checkPermission(50)(interaction))) return;

    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason');

    const securityCheck = await SecurityService.canModerate(interaction, target);

    if (!securityCheck.allowed) {
      return interaction.reply({
        content: securityCheck.reason,
        ephemeral: true
      });
    }

    try {

      const totalWarns = await ModerationService.addWarn(
        interaction,
        target,
        reason
      );

      await interaction.reply(
        `⚠️ ${target.tag} a reçu un avertissement.\nTotal warns : ${totalWarns}`
      );

    } catch (error) {

      console.error("Erreur WARN :", error);

      await interaction.reply({
        content: "❌ Une erreur est survenue.",
        ephemeral: true
      });

    }
  }
};