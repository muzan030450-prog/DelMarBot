const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const Warn = require('../../../database/models/Warn');
const checkWhitelist = require('../../../middlewares/checkWhitelist');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warnings')
    .setDescription('Voir les avertissements d’un membre')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('Utilisateur')
        .setRequired(true)),

  async execute(interaction) {

    if (!(await checkWhitelist(interaction))) return;

    const target = interaction.options.getUser('user');

    const warns = await Warn.findAll({
      where: {
        guild_id: interaction.guild.id,
        user_id: target.id
      },
      order: [['createdAt', 'DESC']]
    });

    if (warns.length === 0) {
      return interaction.reply({
        content: `✅ ${target.tag} n’a aucun avertissement.`,
        ephemeral: true
      });
    }

    const embed = new EmbedBuilder()
      .setTitle(`📊 Avertissements de ${target.tag}`)
      .setColor("Orange")
      .setDescription(
        warns.map((warn, index) =>
          `**#${index + 1}** • ${warn.reason}\nModérateur: <@${warn.moderator_id}>`
        ).join("\n\n")
      )
      .setFooter({ text: `Total : ${warns.length}` })
      .setTimestamp();

    await interaction.reply({
      embeds: [embed],
      ephemeral: true
    });
  }
};