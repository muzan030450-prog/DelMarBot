const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const Warn = require('../../../database/models/Warn');
const checkWhitelist = require('../../../middlewares/checkWhitelist');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warns')
    .setDescription('Voir les avertissements d’un membre')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('Utilisateur')
        .setRequired(true)),

  async execute(interaction) {

    if (!(await checkWhitelist(interaction))) return;

    const target = interaction.options.getUser('user');

    const warns = await Warn.findAll({
      where: {
        guild_id: interaction.guild.id,
        user_id: target.id
      },
      order: [['createdAt', 'DESC']]
    });

    if (!warns.length) {
      return interaction.reply({
        content: `${target.tag} n’a aucun avertissement.`,
        ephemeral: true
      });
    }

    const description = warns
      .map((w, i) =>
        `**#${warns.length - i}** • ${w.reason}\nModérateur: <@${w.moderator_id}>`
      )
      .join("\n\n");

    const embed = new EmbedBuilder()
      .setColor("Orange")
      .setTitle(`📜 Warns de ${target.tag}`)
      .setThumbnail(target.displayAvatarURL())
      .setDescription(description)
      .setFooter({ text: `Total : ${warns.length} avertissement(s)` })
      .setTimestamp();

    interaction.reply({ embeds: [embed], ephemeral: true });
  }
};