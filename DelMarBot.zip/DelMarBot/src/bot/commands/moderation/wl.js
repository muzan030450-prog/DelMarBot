const { SlashCommandBuilder } = require('discord.js');
const WhitelistService = require('../../services/WhitelistService');
const checkPermission = require('../../../middlewares/checkPermission');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('wl')
    .setDescription('Gérer la whitelist')
    .addSubcommand(sub =>
      sub.setName('add')
        .setDescription('Ajouter un utilisateur')
        .addUserOption(opt =>
          opt.setName('user').setDescription('Utilisateur').setRequired(true))
        .addIntegerOption(opt =>
          opt.setName('level').setDescription('Niveau (20/50/80/100)').setRequired(true)))
    .addSubcommand(sub =>
      sub.setName('remove')
        .setDescription('Supprimer un utilisateur')
        .addUserOption(opt =>
          opt.setName('user').setDescription('Utilisateur').setRequired(true)))
    .addSubcommand(sub =>
      sub.setName('list')
        .setDescription('Voir la whitelist')),

  async execute(interaction) {

    if (!(await checkPermission(100)(interaction))) return;

    const sub = interaction.options.getSubcommand();

    if (sub === 'add') {
      const user = interaction.options.getUser('user');
      const level = interaction.options.getInteger('level');

      await WhitelistService.addUser(
        interaction.guild.id,
        user.id,
        level
      );

      return interaction.reply(`✅ ${user.tag} ajouté avec niveau ${level}.`);
    }

    if (sub === 'remove') {
      const user = interaction.options.getUser('user');

      await WhitelistService.removeUser(
        interaction.guild.id,
        user.id
      );

      return interaction.reply(`❌ ${user.tag} retiré de la whitelist.`);
    }

    if (sub === 'list') {
      const list = await WhitelistService.list(interaction.guild.id);

      if (!list.length) {
        return interaction.reply("Whitelist vide.");
      }

      const formatted = list
        .map(u => `<@${u.user_id}> → Niveau ${u.level}`)
        .join("\n");

      return interaction.reply(formatted);
    }
  }
};