const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const XpService = require('../../services/XpService');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('leaderboard')
    .setDescription('Voir le classement XP du serveur'),

  async execute(interaction) {

    const leaderboard = await XpService.getLeaderboard(
      interaction.guild.id
    );

    if (!leaderboard.length) {
      return interaction.reply("Aucun classement disponible.");
    }

    const formatted = leaderboard
      .map((user, index) =>
        `**#${index + 1}** <@${user.user_id}> — Niveau ${user.level}`
      )
      .join("\n");

    const embed = new EmbedBuilder()
      .setColor("Gold")
      .setTitle("🏆 Leaderboard XP")
      .setDescription(formatted)
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};