const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const XpService = require('../../services/XpService');

function createProgressBar(current, required, size = 20) {
  const percentage = current / required;
  const filled = Math.round(size * percentage);
  const empty = size - filled;

  return "🟩".repeat(filled) + "⬜".repeat(empty);
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rank')
    .setDescription('Voir ton niveau ou celui d’un utilisateur')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('Utilisateur')
        .setRequired(false)
    ),

  async execute(interaction) {

    const user = interaction.options.getUser('user') || interaction.user;

    const data = await XpService.getRank(
      interaction.guild.id,
      user.id
    );

    if (!data) {
      return interaction.reply({
        content: "❌ Aucun XP trouvé.",
        ephemeral: true
      });
    }

    const progressBar = createProgressBar(data.xp, data.requiredXp);

    const embed = new EmbedBuilder()
      .setColor("#00bfff")
      .setTitle(`📊 Rang de ${user.username}`)
      .addFields(
        { name: "🎖 Niveau", value: `${data.level}`, inline: true },
        { name: "🏆 Rang", value: `#${data.rank}`, inline: true },
        { name: "📈 XP", value: `${data.xp} / ${data.requiredXp}` },
        { name: "Progression", value: progressBar }
      )
      .setThumbnail(user.displayAvatarURL())
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};