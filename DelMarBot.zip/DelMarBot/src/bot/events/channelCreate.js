const { EmbedBuilder, ChannelType, AuditLogEvent } = require('discord.js');
const GuildConfig = require('../../database/models/GuildConfig');

module.exports = {
  name: 'channelCreate',
  async execute(channelCreated) {

    if (!channelCreated.guild) return;

    const config = await GuildConfig.findOne({
      where: { guild_id: channelCreated.guild.id }
    });

    if (!config?.log_channel) return;

    const logChannel = channelCreated.guild.channels.cache.get(config.log_channel);
    if (!logChannel) return;

    // 🔍 Audit log pour savoir qui a créé
    let executor = null;
    try {
      const logs = await channelCreated.guild.fetchAuditLogs({
        limit: 1,
        type: AuditLogEvent.ChannelCreate
      });

      const entry = logs.entries.first();
      if (entry && entry.target.id === channelCreated.id) {
        executor = entry.executor;
      }
    } catch (err) {
      console.error("Erreur audit log:", err);
    }

    // 🎯 Déterminer type
    let type = "Autre";

    switch (channelCreated.type) {
      case ChannelType.GuildText:
        type = "📝 Textuel";
        break;
      case ChannelType.GuildVoice:
        type = "🎙 Vocal";
        break;
      case ChannelType.GuildCategory:
        type = "📁 Catégorie";
        break;
      case ChannelType.GuildAnnouncement:
        type = "📢 Annonce";
        break;
      case ChannelType.GuildStageVoice:
        type = "🎤 Stage";
        break;
      case ChannelType.PublicThread:
        type = "🧵 Thread public";
        break;
      case ChannelType.PrivateThread:
        type = "🔒 Thread privé";
        break;
    }

    const parentCategory = channelCreated.parent
      ? channelCreated.parent.name
      : "Aucune";

    const embed = new EmbedBuilder()
      .setColor("Purple")
      .setTitle("📁 Salon créé")
      .addFields(
        { name: "Nom", value: channelCreated.name, inline: true },
        { name: "Type", value: type, inline: true },
        { name: "Catégorie", value: parentCategory, inline: true },
        { name: "Position", value: `${channelCreated.position}`, inline: true },
        { name: "Créé par", value: executor ? `<@${executor.id}>` : "Inconnu", inline: true },
        { name: "ID", value: channelCreated.id }
      )
      .setTimestamp();

    await logChannel.send({ embeds: [embed] });
  }
};