const { EmbedBuilder, AuditLogEvent, ChannelType } = require('discord.js');
const GuildConfig = require('../../database/models/GuildConfig');
const AntiRaidService = require('../services/AntiRaidService');
const AdminAbuseProtectionService = require('../services/AdminAbuseProtectionService');
const LogSetupService = require('../services/LogSetupService');

module.exports = {
  name: 'channelDelete',
  async execute(channelDeleted) {

    if (!channelDeleted.guild) return;

    const config = await GuildConfig.findOne({
      where: { guild_id: channelDeleted.guild.id }
    });

    const logChannel = config?.log_channel
      ? channelDeleted.guild.channels.cache.get(config.log_channel)
      : null;

    // 🔍 Audit log
    const logs = await channelDeleted.guild.fetchAuditLogs({
      limit: 1,
      type: AuditLogEvent.ChannelDelete
    });

    const entry = logs.entries.first();
    const executor = entry?.executor;

    // =====================================================
    // 🔐 1️⃣ PROTECTION CATÉGORIE LOGS
    // =====================================================
    if (
      channelDeleted.type === ChannelType.GuildCategory &&
      channelDeleted.name.includes("DELMAR")
    ) {

      console.log("Tentative suppression catégorie logs détectée.");

      // 🔄 Recréation immédiate
      await LogSetupService.setupLogs(channelDeleted.guild);

      if (logChannel) {
        await logChannel.send({
          embeds: [
            new EmbedBuilder()
              .setColor("DarkRed")
              .setTitle("🚨 TENTATIVE SUPPRESSION LOGS BLOQUÉE")
              .setDescription(
                executor
                  ? `<@${executor.id}> a tenté de supprimer la catégorie logs.`
                  : "Tentative inconnue."
              )
              .setTimestamp()
          ]
        });
      }

      return; // stop ici
    }

    // =====================================================
    // 🔄 2️⃣ RECRÉATION SI SALON LOG SUPPRIMÉ
    // =====================================================
    const protectedLogs = [
      "🛠┃mod-logs",
      "💬┃message-logs",
      "🚪┃join-logs",
      "🛡┃security-logs",
      "🌍┃server-logs"
    ];

    if (protectedLogs.includes(channelDeleted.name)) {
      await LogSetupService.setupLogs(channelDeleted.guild);
    }

    // =====================================================
    // 🛡 3️⃣ Anti mass delete (raid simple)
    // =====================================================
    await AntiRaidService.handleChannelDelete(channelDeleted);

    // =====================================================
    // 🚨 4️⃣ Protection Admin Abuse
    // =====================================================
    await AdminAbuseProtectionService.handleAction(
      channelDeleted.guild,
      AuditLogEvent.ChannelDelete
    );

    // =====================================================
    // 📜 5️⃣ Log staff
    // =====================================================
    if (logChannel) {
      const embed = new EmbedBuilder()
        .setColor("Red")
        .setTitle("🧨 Salon supprimé")
        .addFields(
          { name: "Nom", value: channelDeleted.name },
          { name: "Supprimé par", value: executor ? `<@${executor.id}>` : "Inconnu" }
        )
        .setTimestamp();

      await logChannel.send({ embeds: [embed] });
    }
  }
};