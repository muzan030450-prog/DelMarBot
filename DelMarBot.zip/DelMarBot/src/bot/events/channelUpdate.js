const { EmbedBuilder, AuditLogEvent } = require('discord.js');
const GuildConfig = require('../../database/models/GuildConfig');

module.exports = {
  name: 'channelUpdate',
  async execute(oldChannel, newChannel) {

    if (!oldChannel.guild) return;

    const config = await GuildConfig.findOne({
      where: { guild_id: oldChannel.guild.id }
    });

    if (!config?.log_channel) return;

    const logChannel = oldChannel.guild.channels.cache.get(config.log_channel);
    if (!logChannel) return;

    let executor = "Inconnu";

    // 🔍 Audit Log (qui a modifié)
    try {
      const logs = await oldChannel.guild.fetchAuditLogs({
        limit: 1,
        type: AuditLogEvent.ChannelUpdate
      });

      const entry = logs.entries.first();
      if (entry && entry.target.id === oldChannel.id) {
        executor = `<@${entry.executor.id}>`;
      }
    } catch (err) {
      console.error("AuditLog Error:", err);
    }

    const changes = [];

    // 🔤 Nom
    if (oldChannel.name !== newChannel.name) {
      changes.push(`🔤 Nom : **${oldChannel.name}** → **${newChannel.name}**`);
    }

    // 📂 Catégorie
    if (oldChannel.parentId !== newChannel.parentId) {
      changes.push(`📂 Catégorie modifiée`);
    }

    // 📝 Topic
    if (oldChannel.topic !== newChannel.topic) {
      changes.push(`📝 Topic modifié`);
    }

    // 🔞 NSFW
    if (oldChannel.nsfw !== newChannel.nsfw) {
      changes.push(`🔞 NSFW changé`);
    }

    // ⏳ Slowmode
    if (oldChannel.rateLimitPerUser !== newChannel.rateLimitPerUser) {
      changes.push(
        `⏳ Slowmode : ${oldChannel.rateLimitPerUser}s → ${newChannel.rateLimitPerUser}s`
      );
    }

    // 📌 Position
    if (oldChannel.position !== newChannel.position) {
      changes.push(`📌 Position modifiée`);
    }

    // 🔐 Permissions détaillées
    const oldPerms = oldChannel.permissionOverwrites.cache;
    const newPerms = newChannel.permissionOverwrites.cache;

    const permsChanged =
      oldPerms.size !== newPerms.size ||
      oldPerms.some((perm, id) => {
        const newPerm = newPerms.get(id);
        if (!newPerm) return true;

        return (
          perm.allow.bitfield !== newPerm.allow.bitfield ||
          perm.deny.bitfield !== newPerm.deny.bitfield
        );
      });

    if (permsChanged) {
      changes.push(`🔐 Permissions modifiées`);
    }

    if (changes.length === 0) return;

    const embed = new EmbedBuilder()
      .setColor("Yellow")
      .setTitle("🔧 Salon modifié")
      .setDescription(changes.join("\n"))
      .addFields(
        { name: "Salon", value: newChannel.name, inline: true },
        { name: "Modifié par", value: executor, inline: true }
      )
      .setTimestamp();

    await logChannel.send({ embeds: [embed] });
  }
};