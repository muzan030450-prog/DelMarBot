const { AuditLogEvent } = require('discord.js');
const AdminAbuseProtectionService = require('../services/AdminAbuseProtectionService');

module.exports = {
  name: 'guildBanAdd',
  async execute(ban) {

    await AdminAbuseProtectionService.handleAction(
      ban.guild,
      AuditLogEvent.MemberBanAdd
    );
  }
};