const GuildSanctions = require('../../database/models/GuildSanctions');
const LogSetupService = require('../services/LogSetupService');

/**
 * Event déclenché quand le bot rejoint un serveur
 * - Crée automatiquement la configuration sanctions
 * - Crée automatiquement les salons de logs
 */
module.exports = {
  name: 'guildCreate',
  async execute(guild) {

    try {

      // ✅ 1️⃣ Création config sanctions
      await GuildSanctions.findOrCreate({
        where: { guild_id: guild.id }
      });

      console.log(`Configuration sanctions créée pour : ${guild.name}`);

      // ✅ 2️⃣ Création automatique des logs
      const logsCreated = await LogSetupService.setupLogs(guild);

      if (logsCreated) {
        console.log(`Salons de logs créés pour : ${guild.name}`);
      } else {
        console.log(`Logs déjà configurés pour : ${guild.name}`);
      }

    } catch (error) {
      console.error("Erreur création config guild:", error);
    }

  }
};