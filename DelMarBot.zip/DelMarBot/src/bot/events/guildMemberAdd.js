const AntiJoinRaidService = require('../services/AntiJoinRaidService');
const AntiTokenRaidService = require('../services/AntiTokenRaidService');
const AdvancedSecurityService = require('../services/AdvancedSecurityService');
const GuildConfig = require('../../database/models/GuildConfig');
const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'guildMemberAdd',
  async execute(member) {

    const config = await GuildConfig.findOne({
      where: { guild_id: member.guild.id }
    });

    const logChannel = config?.log_channel
      ? member.guild.channels.cache.get(config.log_channel)
      : null;

    // =====================================================
    // 🤖 1️⃣ Kick comptes récents (< 7 jours)
    // =====================================================
    if (AdvancedSecurityService.isRecentAccount(member)) {

      await AdvancedSecurityService.kickWithDM(member);

      if (logChannel) {
        await logChannel.send({
          embeds: [
            new EmbedBuilder()
              .setColor("Orange")
              .setTitle("🤖 Compte récent expulsé")
              .setDescription(`${member.user.tag} (compte < 7 jours)`)
              .setTimestamp()
          ]
        });
      }

      return;
    }

    // =====================================================
    // 🧨 2️⃣ Anti-TOKEN RAID (comptes suspects coordonnés)
    // =====================================================
    const tokenResult = await AntiTokenRaidService.handleJoin(member);

    if (tokenResult.raid) {

      if (logChannel) {
        await logChannel.send({
          embeds: [
            new EmbedBuilder()
              .setColor("DarkRed")
              .setTitle("🧨 TOKEN RAID DÉTECTÉ")
              .setDescription(
                `${tokenResult.suspiciousCount} comptes suspects détectés`
              )
              .setTimestamp()
          ]
        });
      }

      await AdvancedSecurityService.enableSecurityMode(
        member.guild,
        logChannel
      );

      return;
    }

    // =====================================================
    // 🚨 3️⃣ Anti RAID JOIN classique (mass join 15s)
    // =====================================================
    const result = await AntiJoinRaidService.handleJoin(member);

    if (result.raid) {

      if (logChannel) {
        await logChannel.send({
          embeds: [
            new EmbedBuilder()
              .setColor("Red")
              .setTitle("🚨 RAID DÉTECTÉ")
              .setDescription(`${result.count} joins en 15s`)
              .setTimestamp()
          ]
        });
      }

      await AdvancedSecurityService.enableSecurityMode(
        member.guild,
        logChannel
      );
    }
  }
};