const { EmbedBuilder } = require('discord.js');
const GuildConfig = require('../../database/models/GuildConfig');

module.exports = {
  name: 'guildMemberRemove',
  async execute(member) {

    const config = await GuildConfig.findOne({
      where: { guild_id: member.guild.id }
    });

    if (!config?.log_channel) return;

    const channel = member.guild.channels.cache.get(config.log_channel);
    if (!channel) return;

    const embed = new EmbedBuilder()
      .setColor("Red")
      .setTitle("🚪 Membre parti")
      .setDescription(`${member.user.tag} a quitté le serveur`)
      .setTimestamp();

    channel.send({ embeds: [embed] });
  }
};