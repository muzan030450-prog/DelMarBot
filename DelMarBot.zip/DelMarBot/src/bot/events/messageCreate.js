const GuildAntiSpam = require('../../database/models/GuildAntiSpam');
const AntiSpamService = require('../services/AntiSpamService');
const XpService = require('../services/XpService');

module.exports = {
  name: 'messageCreate',
  async execute(message) {

    if (!message.guild) return;
    if (message.author.bot) return;

    // 🔹 Anti message trop court (anti XP farm)
    if (message.content.length < 5) return;

    // 🔹 Auto création config anti-spam
    await GuildAntiSpam.findOrCreate({
      where: { guild_id: message.guild.id }
    });

    // 🔹 Vérification anti-spam
    await AntiSpamService.checkMessage(message);

    // 🔹 SYSTÈME XP INTELLIGENT (nouvelle version)
    const result = await XpService.addXp(
      message.guild,
      message.author.id
    );

    if (result?.leveledUp) {

      const member = await message.guild.members.fetch(message.author.id);

      // 🎖 Attribution rôle automatique
      await XpService.handleRoleReward(member, result.level);

      // 🏅 Message stylé
      message.channel.send(
        `🎉 ${message.author} passe niveau **${result.level}** !`
      );
    }
  }
};