const { EmbedBuilder } = require('discord.js');
const GuildConfig = require('../../database/models/GuildConfig');

module.exports = {
  name: 'messageDelete',
  async execute(message) {

    if (!message.guild || message.author?.bot) return;

    const config = await GuildConfig.findOne({
      where: { guild_id: message.guild.id }
    });

    if (!config?.log_channel) return;

    const channel = message.guild.channels.cache.get(config.log_channel);
    if (!channel) return;

    const embed = new EmbedBuilder()
      .setColor("Orange")
      .setTitle("🗑 Message supprimé")
      .addFields(
        { name: "Utilisateur", value: `<@${message.author.id}>`, inline: true },
        { name: "Salon", value: `<#${message.channel.id}>`, inline: true },
        { name: "Contenu", value: message.content || "Aucun contenu" }
      )
      .setTimestamp();

    channel.send({ embeds: [embed] });
  }
};