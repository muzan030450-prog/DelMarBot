const { EmbedBuilder } = require('discord.js');
const GuildConfig = require('../../database/models/GuildConfig');

module.exports = {
  name: 'messageUpdate',
  async execute(oldMessage, newMessage) {

    if (!oldMessage.guild || oldMessage.author?.bot) return;
    if (oldMessage.content === newMessage.content) return;

    const config = await GuildConfig.findOne({
      where: { guild_id: oldMessage.guild.id }
    });

    if (!config?.log_channel) return;

    const channel = oldMessage.guild.channels.cache.get(config.log_channel);
    if (!channel) return;

    const embed = new EmbedBuilder()
      .setColor("Yellow")
      .setTitle("✏ Message modifié")
      .addFields(
        { name: "Utilisateur", value: `<@${oldMessage.author.id}>` },
        { name: "Ancien", value: oldMessage.content || "Vide" },
        { name: "Nouveau", value: newMessage.content || "Vide" }
      )
      .setTimestamp();

    channel.send({ embeds: [embed] });
  }
};