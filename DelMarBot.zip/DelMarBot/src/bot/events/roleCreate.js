const { EmbedBuilder } = require('discord.js');
const GuildConfig = require('../../database/models/GuildConfig');

module.exports = {
  name: 'roleCreate',
  async execute(role) {

    const config = await GuildConfig.findOne({
      where: { guild_id: role.guild.id }
    });

    if (!config?.log_channel) return;

    const channel = role.guild.channels.cache.get(config.log_channel);

    const embed = new EmbedBuilder()
      .setColor("Blue")
      .setTitle("🆕 Rôle créé")
      .setDescription(`Nom : ${role.name}`)
      .setTimestamp();

    channel.send({ embeds: [embed] });
  }
};