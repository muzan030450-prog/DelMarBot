const { AuditLogEvent } = require('discord.js');
const AdminAbuseProtectionService = require('../services/AdminAbuseProtectionService');

module.exports = {
  name: 'roleDelete',
  async execute(role) {

    await AdminAbuseProtectionService.handleAction(
      role.guild,
      AuditLogEvent.RoleDelete
    );
  }
};