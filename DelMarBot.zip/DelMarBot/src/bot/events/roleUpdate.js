const { EmbedBuilder, AuditLogEvent } = require('discord.js');
const GuildConfig = require('../../database/models/GuildConfig');

module.exports = {
  name: 'roleUpdate',
  async execute(oldRole, newRole) {

    const config = await GuildConfig.findOne({
      where: { guild_id: newRole.guild.id }
    });

    if (!config?.log_channel) return;

    const logChannel = newRole.guild.channels.cache.get(config.log_channel);
    if (!logChannel) return;

    let executor = "Inconnu";

    try {
      const logs = await newRole.guild.fetchAuditLogs({
        limit: 1,
        type: AuditLogEvent.RoleUpdate
      });

      const entry = logs.entries.first();
      if (entry && entry.target.id === newRole.id) {
        executor = `<@${entry.executor.id}>`;
      }
    } catch {}

    const changes = [];

    if (oldRole.name !== newRole.name) {
      changes.push(`🔤 Nom : ${oldRole.name} → ${newRole.name}`);
    }

    if (oldRole.color !== newRole.color) {
      changes.push(`🎨 Couleur modifiée`);
    }

    if (oldRole.permissions.bitfield !== newRole.permissions.bitfield) {
      changes.push(`🔐 Permissions modifiées`);
    }

    if (changes.length === 0) return;

    const embed = new EmbedBuilder()
      .setColor("Blue")
      .setTitle("📜 Rôle modifié")
      .setDescription(changes.join("\n"))
      .addFields(
        { name: "Rôle", value: newRole.name, inline: true },
        { name: "Modifié par", value: executor, inline: true }
      )
      .setTimestamp();

    await logChannel.send({ embeds: [embed] });
  }
};