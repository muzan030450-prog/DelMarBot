const XpService = require('../services/XpService');

const activeVoiceUsers = new Map();

module.exports = {
  name: 'voiceStateUpdate',
  async execute(oldState, newState) {

    const member = newState.member;
    if (!member || member.user.bot) return;

    const guild = newState.guild;
    const userId = member.id;

    // 🔹 Rejoint un salon vocal
    if (!oldState.channelId && newState.channelId) {

      const interval = setInterval(async () => {

        const voiceChannel = member.voice.channel;

        // ❌ Quitte salon
        if (!voiceChannel) {
          clearInterval(interval);
          activeVoiceUsers.delete(userId);
          return;
        }

        // ❌ Seul dans le salon
        if (voiceChannel.members.size <= 1) return;

        // ❌ Muet ou sourd
        if (
          member.voice.selfMute ||
          member.voice.serverMute ||
          member.voice.selfDeaf ||
          member.voice.serverDeaf
        ) return;

        // 🎙 Ajout XP vocal intelligent
        const result = await XpService.addXp(guild, userId);

        // 🎉 Si level up
        if (result?.leveledUp) {

          await XpService.handleRoleReward(member, result.level);

          const textChannel = guild.systemChannel;
          if (textChannel) {
            textChannel.send(
              `🎙 ${member.user} passe niveau **${result.level}** grâce au vocal !`
            ).catch(() => {});
          }
        }

      }, 60000); // 1 minute

      activeVoiceUsers.set(userId, interval);
    }

    // 🔹 Quitte salon vocal
    if (oldState.channelId && !newState.channelId) {

      if (activeVoiceUsers.has(userId)) {
        clearInterval(activeVoiceUsers.get(userId));
        activeVoiceUsers.delete(userId);
      }
    }
  }
};