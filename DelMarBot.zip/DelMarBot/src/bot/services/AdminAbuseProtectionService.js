const { AuditLogEvent, PermissionFlagsBits } = require('discord.js');

const actionTracker = new Map();

class AdminAbuseProtectionService {

  static MAX_ACTIONS = 3;
  static TIME_WINDOW = 10000; // 10 sec

  static async handleAction(guild, type) {

    const logs = await guild.fetchAuditLogs({
      limit: 1,
      type
    });

    const entry = logs.entries.first();
    if (!entry) return;

    const executor = entry.executor;
    if (!executor || executor.bot) return;

    const key = `${guild.id}-${executor.id}-${type}`;
    const now = Date.now();

    if (!actionTracker.has(key)) {
      actionTracker.set(key, { count: 1, timestamp: now });
      return;
    }

    const data = actionTracker.get(key);

    if (now - data.timestamp > this.TIME_WINDOW) {
      actionTracker.set(key, { count: 1, timestamp: now });
      return;
    }

    data.count++;

    if (data.count >= this.MAX_ACTIONS) {

      const member = await guild.members.fetch(executor.id);

      // 🔐 Retrait permissions sensibles
      await member.timeout(5 * 60 * 1000, "Admin Abuse Protection");

      actionTracker.delete(key);

      console.log(`⚠️ ADMIN ABUSE DETECTED: ${executor.tag}`);
    }
  }
}

module.exports = AdminAbuseProtectionService;