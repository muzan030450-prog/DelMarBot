const { EmbedBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');

let securityMode = new Map();

class AdvancedSecurityService {

  static ACCOUNT_MIN_AGE_DAYS = 7;
  static SECURITY_DURATION = 5 * 60 * 1000; // 5 minutes

  // =====================================================
  // 🧠 Détection compte récent
  // =====================================================
  static isRecentAccount(member) {

    if (!member || !member.user) return false;

    const accountAge =
      (Date.now() - member.user.createdTimestamp) /
      (1000 * 60 * 60 * 24);

    return accountAge < this.ACCOUNT_MIN_AGE_DAYS;
  }

  // =====================================================
  // 🚫 Kick avec DM sécurisé
  // =====================================================
  static async kickWithDM(member) {

    if (!member || !member.guild) return;

    try {
      await member.send(
        "🚫 Votre compte est trop récent pour rejoindre ce serveur.\n\n" +
        "Vous pouvez rejoindre plus tard via :\n" +
        "https://discord.com/servers/la-famille-lgbt-1200834033815404637"
      );
    } catch {}

    try {

      // 🔒 Vérification hiérarchie
      const botMember = member.guild.members.me;

      if (
        !member.kickable ||
        member.roles.highest.position >= botMember.roles.highest.position
      ) {
        console.log("Impossible de kick (hiérarchie ou permission).");
        return;
      }

      await member.kick("Compte trop récent - Protection anti-raid");

    } catch (error) {
      console.log("Impossible de kick (permission manquante).");
    }
  }

  // =====================================================
  // 🔐 Mode sécurité
  // =====================================================
  static async enableSecurityMode(guild, logChannel) {

    if (!guild || !guild.available) return;

    if (securityMode.has(guild.id)) return;

    securityMode.set(guild.id, true);

    try {

      // 🔐 Lock uniquement salons textuels classiques
      guild.channels.cache.forEach(channel => {

        if (
          channel.type === ChannelType.GuildText ||
          channel.type === ChannelType.GuildAnnouncement
        ) {

          channel.permissionOverwrites.edit(
            guild.roles.everyone,
            { SendMessages: false }
          ).catch(() => {});
        }

      });

      const embed = new EmbedBuilder()
        .setColor("DarkRed")
        .setTitle("🔐 MODE SÉCURITÉ ACTIVÉ")
        .setDescription("Tous les salons ont été verrouillés temporairement.")
        .setTimestamp();

      if (logChannel) {
        await logChannel.send({ embeds: [embed] });
      }

    } catch (error) {
      console.error("Erreur activation sécurité:", error);
    }

    // =====================================================
    // ⏳ Désactivation automatique
    // =====================================================
    setTimeout(async () => {

      try {

        guild.channels.cache.forEach(channel => {

          if (
            channel.type === ChannelType.GuildText ||
            channel.type === ChannelType.GuildAnnouncement
          ) {

            channel.permissionOverwrites.edit(
              guild.roles.everyone,
              { SendMessages: null }
            ).catch(() => {});
          }

        });

        securityMode.delete(guild.id);

        const embedOff = new EmbedBuilder()
          .setColor("Green")
          .setTitle("🔓 MODE SÉCURITÉ DÉSACTIVÉ")
          .setTimestamp();

        if (logChannel) {
          await logChannel.send({ embeds: [embedOff] });
        }

      } catch (error) {
        console.error("Erreur désactivation sécurité:", error);
      }

    }, this.SECURITY_DURATION);
  }
}

module.exports = AdvancedSecurityService;