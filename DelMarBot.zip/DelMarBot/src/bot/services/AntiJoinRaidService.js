const joinTracker = new Map();

class AntiJoinRaidService {

  static async handleJoin(member) {

    if (!member.guild) return { raid: false };

    const guildId = member.guild.id;
    const now = Date.now();

    // ⚙️ Configuration (modifiable)
    const TIME_WINDOW = 15000; // 15 secondes
    const MAX_JOINS = 5;

    if (!joinTracker.has(guildId)) {
      joinTracker.set(guildId, {
        count: 1,
        timestamp: now
      });

      return { raid: false };
    }

    const data = joinTracker.get(guildId);

    // ⏳ Reset si hors fenêtre
    if (now - data.timestamp > TIME_WINDOW) {
      joinTracker.set(guildId, {
        count: 1,
        timestamp: now
      });

      return { raid: false };
    }

    data.count++;

    if (data.count >= MAX_JOINS) {

      // 🔄 Reset après détection
      joinTracker.delete(guildId);

      return {
        raid: true,
        count: data.count,
        window: TIME_WINDOW
      };
    }

    return { raid: false };
  }
}

module.exports = AntiJoinRaidService;