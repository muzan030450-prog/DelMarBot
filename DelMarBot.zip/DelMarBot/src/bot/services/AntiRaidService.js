const { AuditLogEvent } = require('discord.js');

const deleteTracker = new Map();

class AntiRaidService {

  static async handleChannelDelete(channel) {

    const guild = channel.guild;

    const logs = await guild.fetchAuditLogs({
      limit: 1,
      type: AuditLogEvent.ChannelDelete
    });

    const entry = logs.entries.first();
    if (!entry) return;

    const executor = entry.executor;
    if (!executor || executor.bot) return;

    const key = `${guild.id}-${executor.id}`;

    if (!deleteTracker.has(key)) {
      deleteTracker.set(key, {
        count: 1,
        timestamp: Date.now()
      });
      return;
    }

    const data = deleteTracker.get(key);

    if (Date.now() - data.timestamp > 10000) {
      // reset après 10 sec
      deleteTracker.set(key, {
        count: 1,
        timestamp: Date.now()
      });
      return;
    }

    data.count++;

    if (data.count >= 3) {
      const member = await guild.members.fetch(executor.id);
      await member.timeout(60_000, "Anti-Mass Channel Delete");

      deleteTracker.delete(key);
    }
  }
}

module.exports = AntiRaidService;