const GuildAntiSpam = require('../../database/models/GuildAntiSpam');
const ModerationService = require('./ModerationService');

const messageCache = new Map();

class AntiSpamService {

  static async checkMessage(message) {

    if (!message.guild) return;
    if (message.author.bot) return;

    const config = await GuildAntiSpam.findOne({
      where: { guild_id: message.guild.id }
    });

    if (!config) return;

    const userId = message.author.id;
    const now = Date.now();

    // =============================
    // 1️⃣ FLOOD CHECK
    // =============================

    if (!messageCache.has(userId)) {
      messageCache.set(userId, []);
    }

    const userMessages = messageCache.get(userId);

    userMessages.push(now);

    const interval = config.interval_seconds * 1000;

    const filtered = userMessages.filter(time => now - time < interval);

    messageCache.set(userId, filtered);

    if (filtered.length >= config.max_messages) {
      await message.delete().catch(() => {});
      return this.punish(message, "Spam/Flood détecté");
    }

    // =============================
    // 2️⃣ CAPS CHECK
    // =============================

    const content = message.content;
    const letters = content.replace(/[^a-zA-Z]/g, "");
    const caps = letters.replace(/[^A-Z]/g, "");

    if (letters.length > 5) {
      const percent = (caps.length / letters.length) * 100;

      if (percent >= config.max_caps_percent) {
        await message.delete().catch(() => {});
        return this.punish(message, "Abus de majuscules");
      }
    }

    // =============================
    // 3️⃣ LINK CHECK
    // =============================

    if (config.block_links) {
      const linkRegex = /(https?:\/\/[^\s]+)/g;

      if (linkRegex.test(content)) {
        await message.delete().catch(() => {});
        return this.punish(message, "Lien non autorisé");
      }
    }

    // =============================
    // 4️⃣ REPEAT MESSAGE CHECK
    // =============================

    if (filtered.length >= 3) {
      const lastMessages = filtered.slice(-3);

      if (lastMessages.length === 3) {
        const lastContent = message.content;

        const similar = userMessages.filter(() => lastContent === message.content);

        if (similar.length >= 3) {
          await message.delete().catch(() => {});
          return this.punish(message, "Spam répétitif");
        }
      }
    }
  }

  static async punish(message, reason) {

    await ModerationService.addWarn(
      {
        guild: message.guild,
        user: message.author,
        options: null
      },
      message.author,
      reason
    );

    await message.channel.send(
      `⚠️ ${message.author}, ${reason}`
    ).then(msg => {
      setTimeout(() => msg.delete().catch(() => {}), 5000);
    });
  }
}

module.exports = AntiSpamService;