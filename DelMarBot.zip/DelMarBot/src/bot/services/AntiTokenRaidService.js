const joinData = new Map();

class AntiTokenRaidService {

  static TIME_WINDOW = 20000; // 20 sec
  static MAX_SUSPICIOUS = 4; // 4 comptes suspects en 20 sec = raid
  static MIN_ACCOUNT_AGE_DAYS = 3;

  static isSuspicious(member) {
    const accountAge =
      (Date.now() - member.user.createdTimestamp) / (1000 * 60 * 60 * 24);

    const noAvatar = !member.user.avatar;

    return (
      accountAge < this.MIN_ACCOUNT_AGE_DAYS ||
      noAvatar
    );
  }

  static async handleJoin(member) {

    const guildId = member.guild.id;
    const now = Date.now();

    if (!this.isSuspicious(member)) {
      return { raid: false };
    }

    if (!joinData.has(guildId)) {
      joinData.set(guildId, {
        count: 1,
        timestamp: now
      });
      return { raid: false };
    }

    const data = joinData.get(guildId);

    if (now - data.timestamp > this.TIME_WINDOW) {
      joinData.set(guildId, {
        count: 1,
        timestamp: now
      });
      return { raid: false };
    }

    data.count++;

    if (data.count >= this.MAX_SUSPICIOUS) {
      joinData.delete(guildId);
      return {
        raid: true,
        suspiciousCount: data.count
      };
    }

    return { raid: false };
  }
}

module.exports = AntiTokenRaidService;