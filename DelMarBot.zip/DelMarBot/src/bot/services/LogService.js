const { EmbedBuilder } = require('discord.js');
const GuildConfig = require('../../database/models/GuildConfig');

class LogService {

  static async logModeration(guild, action, target, moderator, reason) {

    const config = await GuildConfig.findOne({
      where: { guild_id: guild.id }
    });

    if (!config || !config.log_channel) return;

    const channel = guild.channels.cache.get(config.log_channel);
    if (!channel) return;

    const embed = new EmbedBuilder()
      .setTitle("📋 Modération Log")
      .setColor("Red")
      .addFields(
        { name: "Action", value: action, inline: true },
        { name: "Utilisateur", value: `<@${target.id}>`, inline: true },
        { name: "Modérateur", value: moderator ? `<@${moderator.id}>` : "Automatique", inline: true },
        { name: "Raison", value: reason }
      )
      .setTimestamp();

    await channel.send({ embeds: [embed] });
  }
}
console.log("LOGSERVICE FILE LOADED FROM:", __filename);
module.exports = LogService;