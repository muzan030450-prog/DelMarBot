const { ChannelType, PermissionsBitField } = require('discord.js');
const GuildConfig = require('../../database/models/GuildConfig');

class LogSetupService {

  static async setupLogs(guild) {

    // =====================================================
    // 🔎 Vérifier si catégorie DELMAR déjà existante
    // =====================================================
    const existingCategory = guild.channels.cache.find(
      c =>
        c.type === ChannelType.GuildCategory &&
        c.name.includes("DELMAR")
    );

    // Vérifier config DB
    const existingConfig = await GuildConfig.findOne({
      where: { guild_id: guild.id }
    });

    if (existingCategory && existingConfig?.log_channel) {
      return false;
    }

    // =====================================================
    // 📁 Création catégorie PREMIUM
    // =====================================================
    const category = await guild.channels.create({
      name: "📜┃DELMAR LOGS",
      type: ChannelType.GuildCategory,
      permissionOverwrites: [
        {
          id: guild.roles.everyone.id,
          deny: [
            PermissionsBitField.Flags.ViewChannel
          ]
        }
      ]
    });

    // =====================================================
    // 🔒 Donner accès à TOUS les rôles admin
    // =====================================================
    const adminRoles = guild.roles.cache.filter(role =>
      role.permissions.has(PermissionsBitField.Flags.Administrator)
    );

    for (const role of adminRoles.values()) {
      await category.permissionOverwrites.create(role, {
        ViewChannel: true,
        SendMessages: true,
        ManageChannels: true
      });
    }

    // =====================================================
    // 📜 Création salons DESIGN
    // =====================================================
    const channels = {};

    const logNames = [
      "🛠┃mod-logs",
      "💬┃message-logs",
      "🚪┃join-logs",
      "🛡┃security-logs",
      "🌍┃server-logs"
    ];

    for (const name of logNames) {
      const channel = await guild.channels.create({
        name,
        type: ChannelType.GuildText,
        parent: category.id
      });

      channels[name] = channel;
    }

    // =====================================================
    // 💾 Sauvegarder canal principal
    // =====================================================
    if (!existingConfig) {
      await GuildConfig.create({
        guild_id: guild.id,
        log_channel: channels["🛠┃mod-logs"].id
      });
    } else {
      existingConfig.log_channel = channels["🛠┃mod-logs"].id;
      await existingConfig.save();
    }

    return true;
  }
}

module.exports = LogSetupService;