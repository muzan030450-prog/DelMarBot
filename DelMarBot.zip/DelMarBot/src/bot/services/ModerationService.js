const Warn = require('../../database/models/Warn');
const LogService = require('./LogService');

class ModerationService {

  static async addWarn(interaction, target, reason) {

    const guild = interaction.guild;

    await Warn.create({
      guild_id: guild.id,
      user_id: target.id,
      moderator_id: interaction.user.id,
      reason
    });

    const totalWarns = await Warn.count({
      where: {
        guild_id: guild.id,
        user_id: target.id
      }
    });

    let member;

    try {
      member = await guild.members.fetch(target.id);
    } catch {
      member = null;
    }

    // Si le membre n'est plus là → stop
    if (!member) {
      return totalWarns;
    }

    // 🔒 Sécurité hiérarchie
    const botMember = guild.members.me;

    const cannotModerate =
      !member.moderatable ||
      member.roles.highest.position >= botMember.roles.highest.position;

    // 🎯 SANCTIONS PROGRESSIVES SÉCURISÉES

    try {

      if (cannotModerate) {
        console.log("⚠️ Impossible de modérer (hiérarchie ou admin).");
      } else {

        if (totalWarns === 2) {
          await member.timeout(
            10 * 60 * 1000,
            "2 warns - Mute automatique"
          );
        }

        if (totalWarns === 3) {
          await member.kick("3 warns - Kick automatique");
        }

        if (totalWarns >= 4) {
          await member.ban({
            reason: "4 warns - Ban automatique"
          });
        }

      }

    } catch (error) {

      if (error.code === 50013) {
        console.log("❌ Permission manquante pour sanction.");
      } else {
        console.error("Erreur sanction:", error);
      }
    }

    await LogService.logModeration(
      guild,
      `WARN (${totalWarns})`,
      target,
      interaction.user,
      reason
    );

    return totalWarns;
  }
}

module.exports = ModerationService;