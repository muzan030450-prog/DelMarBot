class SecurityService {

  /**
   * Vérifie si une action de modération est autorisée
   */
  static async canModerate(interaction, targetUser) {

    const guild = interaction.guild;

    const moderator = await guild.members.fetch(interaction.user.id);
    const target = await guild.members.fetch(targetUser.id);
    const botMember = await guild.members.fetchMe();

    // ❌ Empêcher action sur soi-même
    if (target.id === moderator.id) {
      return {
        allowed: false,
        reason: "❌ Vous ne pouvez pas vous sanctionner vous-même."
      };
    }

    // ❌ Empêcher action sur le bot
    if (target.id === botMember.id) {
      return {
        allowed: false,
        reason: "❌ Vous ne pouvez pas sanctionner le bot."
      };
    }

    // ❌ Empêcher action sur owner
    if (target.id === guild.ownerId) {
      return {
        allowed: false,
        reason: "❌ Impossible de sanctionner le propriétaire du serveur."
      };
    }

    // ❌ Hiérarchie modérateur vs cible
    if (moderator.roles.highest.position <= target.roles.highest.position) {
      return {
        allowed: false,
        reason: "❌ Vous ne pouvez pas sanctionner un membre ayant un rôle supérieur ou égal au vôtre."
      };
    }

    // ❌ Hiérarchie bot vs cible
    if (botMember.roles.highest.position <= target.roles.highest.position) {
      return {
        allowed: false,
        reason: "❌ Le bot ne peut pas sanctionner ce membre (rôle trop élevé)."
      };
    }

    return { allowed: true };
  }
}

module.exports = SecurityService;