const Whitelist = require('../../database/models/Whitelist');

class WhitelistService {

  static async getUserLevel(guildId, userId) {
    const entry = await Whitelist.findOne({
      where: { guild_id: guildId, user_id: userId }
    });

    return entry ? entry.level : 0;
  }

  static async isWhitelisted(guildId, userId) {
    const level = await this.getUserLevel(guildId, userId);
    return level > 0;
  }

  static async hasPermission(guildId, userId, requiredLevel) {
    const level = await this.getUserLevel(guildId, userId);
    return level >= requiredLevel;
  }

  static async addUser(guildId, userId, level) {
    return Whitelist.upsert({
      guild_id: guildId,
      user_id: userId,
      level
    });
  }

  static async removeUser(guildId, userId) {
    return Whitelist.destroy({
      where: { guild_id: guildId, user_id: userId }
    });
  }

  static async list(guildId) {
    return Whitelist.findAll({
      where: { guild_id: guildId }
    });
  }
}

module.exports = WhitelistService;