const Xp = require('../../database/models/Xp');
const { Op } = require('sequelize');

class XpService {

  // 📈 XP requis pour level suivant
  static calculateRequiredXp(level) {
    return 100 + (level * 50);
  }

  // ➕ Ajouter XP
  static async addXp(guild, userId) {

    const guildId = guild.id;

    let data = await Xp.findOne({
      where: { guild_id: guildId, user_id: userId }
    });

    if (!data) {
      data = await Xp.create({
        guild_id: guildId,
        user_id: userId,
        xp: 0,
        level: 0
      });
    }

    const now = new Date();

    // 🛡 Anti-farm avancé
    if (data.last_message) {
      const diff = (now - data.last_message) / 1000;

      // Cooldown dynamique
      if (diff < 20) return null;
    }

    // 🎲 XP random sécurisé
    const randomXp = Math.floor(Math.random() * 6) + 5; // 5 à 10 XP
    data.xp += randomXp;
    data.last_message = now;

    let leveledUp = false;
    let newLevel = data.level;

    // 🔄 Multi-level up sécurisé
    while (data.xp >= this.calculateRequiredXp(newLevel)) {
      data.xp -= this.calculateRequiredXp(newLevel);
      newLevel++;
      leveledUp = true;
    }

    data.level = newLevel;
    await data.save();

    return {
      level: data.level,
      xp: data.xp,
      requiredXp: this.calculateRequiredXp(data.level),
      leveledUp,
      gainedXp: randomXp
    };
  }

  // 🎖 Attribution rôles automatique
  static async handleRoleReward(member, level) {

    const rewards = {
      5: "ID_ROLE_NIVEAU_5",
      10: "ID_ROLE_NIVEAU_10",
      20: "ID_ROLE_NIVEAU_20",
      30: "ID_ROLE_VIP"
    };

    if (!rewards[level]) return;

    const role = member.guild.roles.cache.get(rewards[level]);
    if (!role) return;

    await member.roles.add(role).catch(() => {});
  }

  // 📊 Obtenir rang utilisateur
  static async getRank(guildId, userId) {

    const data = await Xp.findOne({
      where: { guild_id: guildId, user_id: userId }
    });

    if (!data) return null;

    const countHigher = await Xp.count({
      where: {
        guild_id: guildId,
        level: {
          [Op.gt]: data.level
        }
      }
    });

    return {
      level: data.level,
      xp: data.xp,
      requiredXp: this.calculateRequiredXp(data.level),
      rank: countHigher + 1
    };
  }

  // 🏆 Leaderboard Top 10
  static async getLeaderboard(guildId) {

    return await Xp.findAll({
      where: { guild_id: guildId },
      order: [['level', 'DESC'], ['xp', 'DESC']],
      limit: 10
    });
  }
}

module.exports = XpService;