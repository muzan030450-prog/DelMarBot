const express = require('express');
const session = require('express-session');
const passport = require('./auth/passport');
const expressLayouts = require('express-ejs-layouts');
require('dotenv').config();

const app = express();

app.set('trust proxy', 1);

// View engine
app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');

// Layout system
app.use(expressLayouts);
app.set('layout', 'layout'); // layout.ejs

app.use(express.static(__dirname + '/public'));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(
  session({
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: true,
      httpOnly: true,
      maxAge: 1000 * 60 * 60 * 24
    }
  })
);

app.use(passport.initialize());
app.use(passport.session());

// Routes
app.use('/', require('./routes/auth'));
app.use('/dashboard', require('./routes/dashboard'));
app.use('/dashboard', require('./routes/moderation'));
app.use('/dashboard', require('./routes/xp'));
app.use('/dashboard', require('./routes/security'));
app.use('/dashboard', require('./routes/logs'));

module.exports = app;