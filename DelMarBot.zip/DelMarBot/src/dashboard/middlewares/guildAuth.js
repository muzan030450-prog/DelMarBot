const client = require('../../bot/client');

module.exports = function (req, res, next) {

  if (!req.isAuthenticated()) return res.redirect('/');

  const guildId = req.params.guildId;
  const guild = client.guilds.cache.get(guildId);

  if (!guild) return res.send("Bot non présent sur ce serveur.");

  req.guild = guild;
  next();
};