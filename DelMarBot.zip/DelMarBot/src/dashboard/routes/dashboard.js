const express = require('express');
const axios = require('axios');
const client = require('../../bot/client');

const router = express.Router();

function isAuthenticated(req, res, next) {
  if (req.isAuthenticated()) return next();
  return res.redirect('/');
}

router.get('/', isAuthenticated, async (req, res) => {

  try {

    const response = await axios.get(
      'https://discord.com/api/users/@me/guilds',
      {
        headers: {
          Authorization: `Bearer ${req.user.accessToken}`
        }
      }
    );

    const userGuilds = response.data;

    const managedGuilds = userGuilds.filter(guild => {
      const isAdmin = (guild.permissions & 0x8) === 0x8;
      const botInGuild = client.guilds.cache.has(guild.id);
      return isAdmin && botInGuild;
    });

    let html = `<h1>📊 Dashboard</h1>`;

    managedGuilds.forEach(g => {
      html += `<p>${g.name}</p>`;
    });

  res.render('dashboard', {
  user: req.user,
  guilds: managedGuilds
});

  } catch (error) {
    console.error(error);
    res.redirect('/');
  }

});

module.exports = router;