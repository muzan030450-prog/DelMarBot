const router = require('express').Router();
const authMiddleware = require('../middlewares/authMiddleware');

router.get('/', authMiddleware, (req, res) => {

  const guilds = req.user.guilds.filter(g =>
    (g.permissions & 0x20) === 0x20 // Manage Guild
  );

  res.json({
    user: {
      id: req.user.id,
      username: req.user.username,
      avatar: req.user.avatar
    },
    guilds
  });
});

module.exports = router;