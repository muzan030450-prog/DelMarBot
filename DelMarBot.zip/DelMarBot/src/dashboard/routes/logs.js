const express = require('express');
const GuildConfig = require('../../database/models/GuildConfig');
const guildAuth = require('../middlewares/guildAuth');

const router = express.Router();

router.get('/:guildId/logs', guildAuth, async (req, res) => {

  const config = await GuildConfig.findOne({
    where: { guild_id: req.guild.id }
  });

  res.send(`
    <h1>📜 Logs - ${req.guild.name}</h1>

    <form method="POST">
      <label>ID Salon logs :</label>
      <input name="log_channel" value="${config?.log_channel || ''}"><br>

      <button type="submit">Sauvegarder</button>
    </form>

    <br>
    <a href="/dashboard/${req.guild.id}">⬅ Retour</a>
  `);
});

router.post('/:guildId/logs', guildAuth, async (req, res) => {

  await GuildConfig.update({
    log_channel: req.body.log_channel
  }, {
    where: { guild_id: req.guild.id }
  });

  res.redirect(`/dashboard/${req.guild.id}/logs`);
});

module.exports = router;