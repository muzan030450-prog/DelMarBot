const express = require('express');
const GuildSanctions = require('../../database/models/GuildSanctions');
const guildAuth = require('../middlewares/guildAuth');
console.log("TYPE guildAuth:", typeof guildAuth);

const router = express.Router();

router.get('/:guildId/moderation', guildAuth, async (req, res) => {

  const config = await GuildSanctions.findOne({
    where: { guild_id: req.guild.id }
  });

  res.send(`
    <h1>🛡 Modération - ${req.guild.name}</h1>

    <form method="POST">
      <label>Warn → Mute :</label>
      <input name="warn_mute" value="${config?.warn_mute || 2}" /><br>

      <label>Warn → Kick :</label>
      <input name="warn_kick" value="${config?.warn_kick || 3}" /><br>

      <label>Warn → Ban :</label>
      <input name="warn_ban" value="${config?.warn_ban || 4}" /><br>

      <button type="submit">Sauvegarder</button>
    </form>

    <br>
    <a href="/dashboard/${req.guild.id}">⬅ Retour</a>
  `);
});

module.exports = router;
