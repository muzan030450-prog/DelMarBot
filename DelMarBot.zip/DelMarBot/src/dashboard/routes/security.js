const express = require('express');
const guildAuth = require('../middlewares/guildAuth');

const router = express.Router();

router.get('/:guildId/security', guildAuth, (req, res) => {

  res.send(`
    <h1>🔐 Sécurité - ${req.guild.name}</h1>

    <form method="POST">
      <label>Mode anti-raid actif :</label>
      <input type="checkbox" name="anti_raid"><br>

      <label>Kick comptes < 7 jours :</label>
      <input type="checkbox" name="recent_kick"><br>

      <button type="submit">Sauvegarder</button>
    </form>

    <br>
    <a href="/dashboard/${req.guild.id}">⬅ Retour</a>
  `);
});

module.exports = router;