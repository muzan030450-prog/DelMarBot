const express = require('express');
const guildAuth = require('../middlewares/guildAuth');

const router = express.Router();

router.get('/:guildId/settings', guildAuth, (req, res) => {
  res.send(`
    <h1>⚙ Paramètres - ${req.guild.name}</h1>
    <p>Page en construction...</p>
    <a href="/dashboard/${req.guild.id}">⬅ Retour</a>
  `);
});

module.exports = router;