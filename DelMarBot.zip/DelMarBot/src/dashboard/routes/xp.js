const express = require('express');
const guildAuth = require('../middlewares/guildAuth');

const router = express.Router();

router.get('/:guildId/xp', guildAuth, async (req, res) => {

  res.send(`
    <h1>🎖 Configuration XP - ${req.guild.name}</h1>

    <form method="POST">
      <label>XP min message :</label>
      <input name="xp_min" value="5"><br>

      <label>XP max message :</label>
      <input name="xp_max" value="15"><br>

      <label>Cooldown (sec) :</label>
      <input name="cooldown" value="30"><br>

      <button type="submit">Sauvegarder</button>
    </form>

    <br>
    <a href="/dashboard/${req.guild.id}">⬅ Retour</a>
  `);
});

router.post('/:guildId/xp', guildAuth, async (req, res) => {
  // plus tard on sauvegardera en base
  res.redirect(`/dashboard/${req.guild.id}/xp`);
});

module.exports = router;