const express = require('express');
const app = express();
const helmet = require('helmet');
const morgan = require('morgan');

app.use(helmet());
app.use(morgan('dev'));
app.use(express.json());

app.get('/', (req, res) => {
  res.send('DelMarBot Dashboard en construction 🚀');
});

module.exports = app;