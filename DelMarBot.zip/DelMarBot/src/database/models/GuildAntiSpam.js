const { DataTypes } = require('sequelize');
const sequelize = require('../connection');

const GuildAntiSpam = sequelize.define('GuildAntiSpam', {
  guild_id: {
    type: DataTypes.STRING,
    primaryKey: true
  },
  max_messages: {
    type: DataTypes.INTEGER,
    defaultValue: 5
  },
  interval_seconds: {
    type: DataTypes.INTEGER,
    defaultValue: 5
  },
  max_caps_percent: {
    type: DataTypes.INTEGER,
    defaultValue: 70
  },
  block_links: {
    type: DataTypes.BOOLEAN,
    defaultValue: true
  }
});

module.exports = GuildAntiSpam;