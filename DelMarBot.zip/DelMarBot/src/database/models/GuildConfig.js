const { DataTypes } = require('sequelize');
const sequelize = require('../connection');

const GuildConfig = sequelize.define('GuildConfig', {
  guild_id: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true
  },
  log_channel: {
    type: DataTypes.STRING,
    allowNull: true
  }
});

module.exports = GuildConfig;
