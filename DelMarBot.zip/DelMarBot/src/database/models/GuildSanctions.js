const { DataTypes } = require('sequelize');
const sequelize = require('../connection');

const GuildSanctions = sequelize.define('GuildSanctions', {
  guild_id: {
    type: DataTypes.STRING,
    primaryKey: true
  },
  warn_mute_threshold: {
    type: DataTypes.INTEGER,
    defaultValue: 2
  },
  warn_mute_duration: {
    type: DataTypes.INTEGER,
    defaultValue: 600
  },
  warn_kick_threshold: {
    type: DataTypes.INTEGER,
    defaultValue: 3
  },
  warn_ban_threshold: {
    type: DataTypes.INTEGER,
    defaultValue: 4
  }
});

module.exports = GuildSanctions;