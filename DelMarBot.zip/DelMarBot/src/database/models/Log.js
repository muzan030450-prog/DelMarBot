const { DataTypes } = require('sequelize');
const sequelize = require('../connection');

const Log = sequelize.define('Log', {
  guild_id: {
    type: DataTypes.STRING,
    allowNull: false
  },
  type: {
    type: DataTypes.STRING,
    allowNull: false
  },
  user_id: {
    type: DataTypes.STRING,
    allowNull: true
  },
  moderator_id: {
    type: DataTypes.STRING,
    allowNull: true
  },
  content: {
    type: DataTypes.TEXT,
    allowNull: true
  }
});

module.exports = Log;