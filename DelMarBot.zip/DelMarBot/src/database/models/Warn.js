const { DataTypes } = require('sequelize');
const sequelize = require('../connection');

const Warn = sequelize.define('Warn', {
  guild_id: {
    type: DataTypes.STRING,
    allowNull: false
  },
  user_id: {
    type: DataTypes.STRING,
    allowNull: false
  },
  moderator_id: {
    type: DataTypes.STRING,
    allowNull: false
  },
  reason: {
    type: DataTypes.STRING,
    allowNull: false
  }
});

module.exports = Warn;