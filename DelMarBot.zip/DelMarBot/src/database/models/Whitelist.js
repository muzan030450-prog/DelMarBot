const { DataTypes } = require('sequelize');
const sequelize = require('../connection');

const Whitelist = sequelize.define('Whitelist', {
  guild_id: {
    type: DataTypes.STRING,
    allowNull: false
  },
  user_id: {
    type: DataTypes.STRING,
    allowNull: false
  },
  level: {
    type: DataTypes.INTEGER,
    allowNull: false
  }
});

module.exports = Whitelist;