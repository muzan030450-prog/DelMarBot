const { DataTypes } = require('sequelize');
const sequelize = require('../connection');

const Xp = sequelize.define('Xp', {
  guild_id: {
    type: DataTypes.STRING,
    allowNull: false
  },
  user_id: {
    type: DataTypes.STRING,
    allowNull: false
  },
  xp: {
    type: DataTypes.INTEGER,
    defaultValue: 0
  },
  level: {
    type: DataTypes.INTEGER,
    defaultValue: 0
  },
  last_message: {
    type: DataTypes.DATE,
    allowNull: true
  }
});

module.exports = Xp;