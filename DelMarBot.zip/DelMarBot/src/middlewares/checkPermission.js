const WhitelistService = require('../bot/services/WhitelistService');

module.exports = (requiredLevel = 50) => {

  return async (interaction) => {

    if (!interaction.guild) return false;

    const member = interaction.member;

    // 🔐 Admin bypass
    if (member.permissions.has('Administrator')) return true;

    // 🛡 Whitelist check
    const isWhitelisted = await WhitelistService.isWhitelisted(
      interaction.guild.id,
      interaction.user.id
    );

    if (!isWhitelisted) {
      await interaction.reply({
        content: "❌ Vous n'êtes pas autorisé à utiliser cette commande.",
        ephemeral: true
      });
      return false;
    }

    return true;
  };
};