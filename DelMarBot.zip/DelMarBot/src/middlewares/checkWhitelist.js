const Whitelist = require('../database/models/Whitelist');

async function checkWhitelist(interaction) {
  const entry = await Whitelist.findOne({
    where: {
      guild_id: interaction.guild.id,
      user_id: interaction.user.id
    }
  });

  if (!entry) {
    await interaction.reply({
      content: "❌ Vous n'êtes pas autorisé à utiliser cette commande.",
      ephemeral: true
    });
    return false;
  }

  return true;
}

module.exports = checkWhitelist;